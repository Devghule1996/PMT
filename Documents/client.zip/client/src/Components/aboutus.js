import React from "react";
export default class Aboutus extends React.Component{
    render(){
        return(
            <div>
                <h1 className="jumbotron">Welcome to aboutus</h1>
            </div>
        )
    }
}