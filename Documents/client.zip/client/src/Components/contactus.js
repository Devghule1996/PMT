import React from "react";
export default class Contactus extends React.Component{
    render(){
        return(
            <div>
                <h1 className="jumbotron bg-dark text-primary">Welcome to Contactus</h1>
            </div>
        )
    }
}